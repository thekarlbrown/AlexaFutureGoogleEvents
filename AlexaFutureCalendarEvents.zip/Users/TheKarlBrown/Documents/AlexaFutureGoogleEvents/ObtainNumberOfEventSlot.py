for count in range (1, 100):
    print (count)
